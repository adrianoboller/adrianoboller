(function(){
  var escuro = document.documentElement.dataset.theme === 'dark' ||
    (document.documentElement.dataset.theme !== 'light' && matchMedia('(prefers-color-scheme: dark)').matches);
  mermaid.initialize({startOnLoad:false, securityLevel:'strict',
    theme: escuro ? 'dark' : 'default',
    themeVariables: escuro ? {background:'#0a1122', primaryColor:'#0a1122', primaryTextColor:'#DDE2EB',
      lineColor:'#8a93a8', clusterBkg:'#050a1c', clusterBorder:'#1c2742'} : {},
    flowchart:{htmlLabels:true, curve:'basis'}});
  function desenhar(sel){ mermaid.run({querySelector: sel + ' .mermaid:not([data-processed])'}); }
  desenhar('#fluxo');
  document.querySelectorAll('nav button').forEach(function(b){
    b.addEventListener('click', function(){
      document.querySelectorAll('nav button').forEach(function(x){ x.setAttribute('aria-selected', x===b); });
      document.querySelectorAll('.aba').forEach(function(s){ s.hidden = s.id !== b.dataset.aba; });
      desenhar('#' + b.dataset.aba);
    });
  });
})();
